﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OrderSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OrderSearch))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtBeginDate = New System.Windows.Forms.DateTimePicker()
        Me.dtEndDate = New System.Windows.Forms.DateTimePicker()
        Me.lblEndDate = New System.Windows.Forms.Label()
        Me.lblBeginDate = New System.Windows.Forms.Label()
        Me.cboLocation = New System.Windows.Forms.ComboBox()
        Me.StoreLocationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BackToRootsDataSet = New BackToRootsForms.BackToRootsDataSet()
        Me.StoreLocationTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.StoreLocationTableAdapter()
        Me.lblLocation = New System.Windows.Forms.Label()
        Me.cboOrderPlacement = New System.Windows.Forms.ComboBox()
        Me.OrderPlacementBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblOrderPlacement = New System.Windows.Forms.Label()
        Me.cboOrderFulfillment = New System.Windows.Forms.ComboBox()
        Me.OrderFulfillmentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblOrderFulfillment = New System.Windows.Forms.Label()
        Me.OrderPlacementTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderPlacementTableAdapter()
        Me.OrderFulfillmentTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderFulfillmentTableAdapter()
        Me.cboEmployee = New System.Windows.Forms.ComboBox()
        Me.EmployeeBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BackToRootsDataSet1 = New BackToRootsForms.BackToRootsDataSet()
        Me.EmployeeTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.EmployeeTableAdapter()
        Me.lblEmployee = New System.Windows.Forms.Label()
        Me.cbEmpAll = New System.Windows.Forms.CheckBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.OrderSearchBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrderSearchTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderSearchTableAdapter()
        Me.TableAdapterManager = New BackToRootsForms.BackToRootsDataSetTableAdapters.TableAdapterManager()
        Me.OrderSearchDataGridView = New System.Windows.Forms.DataGridView()
        Me.OrderID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomerName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LineItems = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ItemsOrdered = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblAvgTotalTitle = New System.Windows.Forms.Label()
        Me.lblTotalTitle = New System.Windows.Forms.Label()
        Me.lblQuantityTitle = New System.Windows.Forms.Label()
        Me.lblTotalQuantityTitle = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.lblTotalItems = New System.Windows.Forms.Label()
        Me.lblAvgTotal = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.OrderSearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrdersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagementToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RewardStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnClose = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StoreLocationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BackToRootsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderPlacementBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderFulfillmentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BackToRootsDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderSearchBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderSearchDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(822, 54)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(118, 161)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(313, 54)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(367, 39)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Back-to-Roots Bakery"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(369, 98)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(234, 31)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "ORDER SEARCH"
        '
        'dtBeginDate
        '
        Me.dtBeginDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtBeginDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtBeginDate.Location = New System.Drawing.Point(298, 161)
        Me.dtBeginDate.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.dtBeginDate.Name = "dtBeginDate"
        Me.dtBeginDate.Size = New System.Drawing.Size(141, 27)
        Me.dtBeginDate.TabIndex = 3
        Me.dtBeginDate.Value = New Date(2018, 2, 13, 18, 35, 0, 0)
        '
        'dtEndDate
        '
        Me.dtEndDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtEndDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtEndDate.Location = New System.Drawing.Point(298, 194)
        Me.dtEndDate.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.dtEndDate.Name = "dtEndDate"
        Me.dtEndDate.Size = New System.Drawing.Size(141, 27)
        Me.dtEndDate.TabIndex = 4
        Me.dtEndDate.Value = New Date(2021, 3, 31, 18, 35, 0, 0)
        '
        'lblEndDate
        '
        Me.lblEndDate.AutoSize = True
        Me.lblEndDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEndDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblEndDate.Location = New System.Drawing.Point(197, 197)
        Me.lblEndDate.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEndDate.Name = "lblEndDate"
        Me.lblEndDate.Size = New System.Drawing.Size(85, 22)
        Me.lblEndDate.TabIndex = 5
        Me.lblEndDate.Text = "End Date"
        '
        'lblBeginDate
        '
        Me.lblBeginDate.AutoSize = True
        Me.lblBeginDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBeginDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblBeginDate.Location = New System.Drawing.Point(197, 164)
        Me.lblBeginDate.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBeginDate.Name = "lblBeginDate"
        Me.lblBeginDate.Size = New System.Drawing.Size(99, 22)
        Me.lblBeginDate.TabIndex = 6
        Me.lblBeginDate.Text = "Begin Date"
        '
        'cboLocation
        '
        Me.cboLocation.DataSource = Me.StoreLocationBindingSource
        Me.cboLocation.DisplayMember = "LocationCity"
        Me.cboLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboLocation.FormattingEnabled = True
        Me.cboLocation.Location = New System.Drawing.Point(628, 161)
        Me.cboLocation.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboLocation.Name = "cboLocation"
        Me.cboLocation.Size = New System.Drawing.Size(141, 28)
        Me.cboLocation.TabIndex = 7
        Me.cboLocation.ValueMember = "LocationCity"
        '
        'StoreLocationBindingSource
        '
        Me.StoreLocationBindingSource.DataMember = "StoreLocation"
        Me.StoreLocationBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'BackToRootsDataSet
        '
        Me.BackToRootsDataSet.DataSetName = "BackToRootsDataSet"
        Me.BackToRootsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StoreLocationTableAdapter
        '
        Me.StoreLocationTableAdapter.ClearBeforeFill = True
        '
        'lblLocation
        '
        Me.lblLocation.AutoSize = True
        Me.lblLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocation.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblLocation.Location = New System.Drawing.Point(534, 164)
        Me.lblLocation.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLocation.Name = "lblLocation"
        Me.lblLocation.Size = New System.Drawing.Size(78, 22)
        Me.lblLocation.TabIndex = 8
        Me.lblLocation.Text = "Location"
        '
        'cboOrderPlacement
        '
        Me.cboOrderPlacement.DataSource = Me.OrderPlacementBindingSource
        Me.cboOrderPlacement.DisplayMember = "OrderPlacement"
        Me.cboOrderPlacement.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboOrderPlacement.FormattingEnabled = True
        Me.cboOrderPlacement.Location = New System.Drawing.Point(628, 193)
        Me.cboOrderPlacement.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboOrderPlacement.Name = "cboOrderPlacement"
        Me.cboOrderPlacement.Size = New System.Drawing.Size(141, 28)
        Me.cboOrderPlacement.TabIndex = 9
        Me.cboOrderPlacement.ValueMember = "OrderPlacement"
        '
        'OrderPlacementBindingSource
        '
        Me.OrderPlacementBindingSource.DataMember = "OrderPlacement"
        Me.OrderPlacementBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'lblOrderPlacement
        '
        Me.lblOrderPlacement.AutoSize = True
        Me.lblOrderPlacement.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrderPlacement.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblOrderPlacement.Location = New System.Drawing.Point(534, 197)
        Me.lblOrderPlacement.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblOrderPlacement.Name = "lblOrderPlacement"
        Me.lblOrderPlacement.Size = New System.Drawing.Size(94, 22)
        Me.lblOrderPlacement.TabIndex = 10
        Me.lblOrderPlacement.Text = "Placement"
        '
        'cboOrderFulfillment
        '
        Me.cboOrderFulfillment.DataSource = Me.OrderFulfillmentBindingSource
        Me.cboOrderFulfillment.DisplayMember = "OrderFulfillment"
        Me.cboOrderFulfillment.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboOrderFulfillment.FormattingEnabled = True
        Me.cboOrderFulfillment.Location = New System.Drawing.Point(628, 226)
        Me.cboOrderFulfillment.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboOrderFulfillment.Name = "cboOrderFulfillment"
        Me.cboOrderFulfillment.Size = New System.Drawing.Size(141, 28)
        Me.cboOrderFulfillment.TabIndex = 11
        Me.cboOrderFulfillment.ValueMember = "OrderFulfillment"
        '
        'OrderFulfillmentBindingSource
        '
        Me.OrderFulfillmentBindingSource.DataMember = "OrderFulfillment"
        Me.OrderFulfillmentBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'lblOrderFulfillment
        '
        Me.lblOrderFulfillment.AutoSize = True
        Me.lblOrderFulfillment.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrderFulfillment.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblOrderFulfillment.Location = New System.Drawing.Point(534, 230)
        Me.lblOrderFulfillment.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblOrderFulfillment.Name = "lblOrderFulfillment"
        Me.lblOrderFulfillment.Size = New System.Drawing.Size(91, 22)
        Me.lblOrderFulfillment.TabIndex = 12
        Me.lblOrderFulfillment.Text = "Fulfillment"
        '
        'OrderPlacementTableAdapter
        '
        Me.OrderPlacementTableAdapter.ClearBeforeFill = True
        '
        'OrderFulfillmentTableAdapter
        '
        Me.OrderFulfillmentTableAdapter.ClearBeforeFill = True
        '
        'cboEmployee
        '
        Me.cboEmployee.DataSource = Me.EmployeeBindingSource1
        Me.cboEmployee.DisplayMember = "EmployeeFullName"
        Me.cboEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboEmployee.FormattingEnabled = True
        Me.cboEmployee.Location = New System.Drawing.Point(298, 226)
        Me.cboEmployee.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboEmployee.Name = "cboEmployee"
        Me.cboEmployee.Size = New System.Drawing.Size(213, 28)
        Me.cboEmployee.TabIndex = 13
        Me.cboEmployee.ValueMember = "EmployeeFullName"
        '
        'EmployeeBindingSource1
        '
        Me.EmployeeBindingSource1.DataMember = "Employee"
        Me.EmployeeBindingSource1.DataSource = Me.BackToRootsDataSet
        '
        'EmployeeBindingSource
        '
        Me.EmployeeBindingSource.DataMember = "Employee"
        Me.EmployeeBindingSource.DataSource = Me.BackToRootsDataSet1
        '
        'BackToRootsDataSet1
        '
        Me.BackToRootsDataSet1.DataSetName = "BackToRootsDataSet"
        Me.BackToRootsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EmployeeTableAdapter
        '
        Me.EmployeeTableAdapter.ClearBeforeFill = True
        '
        'lblEmployee
        '
        Me.lblEmployee.AutoSize = True
        Me.lblEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployee.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblEmployee.Location = New System.Drawing.Point(197, 230)
        Me.lblEmployee.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee.Name = "lblEmployee"
        Me.lblEmployee.Size = New System.Drawing.Size(89, 22)
        Me.lblEmployee.TabIndex = 14
        Me.lblEmployee.Text = "Employee"
        '
        'cbEmpAll
        '
        Me.cbEmpAll.AutoSize = True
        Me.cbEmpAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbEmpAll.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.cbEmpAll.Location = New System.Drawing.Point(298, 262)
        Me.cbEmpAll.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cbEmpAll.Name = "cbEmpAll"
        Me.cbEmpAll.Size = New System.Drawing.Size(168, 22)
        Me.cbEmpAll.TabIndex = 15
        Me.cbEmpAll.Text = "Search all employees"
        Me.cbEmpAll.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.btnSearch.Location = New System.Drawing.Point(651, 261)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(98, 30)
        Me.btnSearch.TabIndex = 16
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'OrderSearchBindingSource
        '
        Me.OrderSearchBindingSource.DataMember = "OrderSearch"
        Me.OrderSearchBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'OrderSearchTableAdapter
        '
        Me.OrderSearchTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CustomerOrderTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Nothing
        Me.TableAdapterManager.DietProductTableAdapter = Nothing
        Me.TableAdapterManager.DietTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Me.EmployeeTableAdapter
        Me.TableAdapterManager.EmploymentHistoryTableAdapter = Nothing
        Me.TableAdapterManager.OrderLineTableAdapter = Nothing
        Me.TableAdapterManager.PositionTableAdapter = Nothing
        Me.TableAdapterManager.ProductTableAdapter = Nothing
        Me.TableAdapterManager.ProductTypeTableAdapter = Nothing
        Me.TableAdapterManager.RewardHistoryTableAdapter = Nothing
        Me.TableAdapterManager.RewardStatusTableAdapter = Nothing
        Me.TableAdapterManager.StoreLocationTableAdapter = Me.StoreLocationTableAdapter
        Me.TableAdapterManager.UpdateOrder = BackToRootsForms.BackToRootsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'OrderSearchDataGridView
        '
        Me.OrderSearchDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.OrderSearchDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.OrderSearchDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.OrderSearchDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.OrderID, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.CustomerName, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.LineItems, Me.ItemsOrdered, Me.OrderTotal})
        Me.OrderSearchDataGridView.DataSource = Me.OrderSearchBindingSource
        Me.OrderSearchDataGridView.Location = New System.Drawing.Point(26, 295)
        Me.OrderSearchDataGridView.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.OrderSearchDataGridView.Name = "OrderSearchDataGridView"
        Me.OrderSearchDataGridView.ReadOnly = True
        Me.OrderSearchDataGridView.RowHeadersWidth = 51
        Me.OrderSearchDataGridView.RowTemplate.Height = 24
        Me.OrderSearchDataGridView.Size = New System.Drawing.Size(914, 209)
        Me.OrderSearchDataGridView.TabIndex = 17
        '
        'OrderID
        '
        Me.OrderID.DataPropertyName = "OrderID"
        Me.OrderID.HeaderText = "OrderID"
        Me.OrderID.MinimumWidth = 6
        Me.OrderID.Name = "OrderID"
        Me.OrderID.ReadOnly = True
        Me.OrderID.Width = 70
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "OrderDate"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Order Date"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 75
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "LocationCity"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Location"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 65
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "EmployeeFullName"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Employee"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'CustomerName
        '
        Me.CustomerName.DataPropertyName = "CustomerFullName"
        Me.CustomerName.HeaderText = "Customer"
        Me.CustomerName.MinimumWidth = 6
        Me.CustomerName.Name = "CustomerName"
        Me.CustomerName.ReadOnly = True
        Me.CustomerName.Width = 150
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "OrderPlacement"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Order Placement"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Width = 75
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "OrderFulfillment"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Order Fulfillment"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 75
        '
        'LineItems
        '
        Me.LineItems.DataPropertyName = "NumLineItems"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.LineItems.DefaultCellStyle = DataGridViewCellStyle2
        Me.LineItems.HeaderText = "Line Items"
        Me.LineItems.MinimumWidth = 6
        Me.LineItems.Name = "LineItems"
        Me.LineItems.ReadOnly = True
        Me.LineItems.Width = 50
        '
        'ItemsOrdered
        '
        Me.ItemsOrdered.DataPropertyName = "TotalNumItemsOrdered"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.ItemsOrdered.DefaultCellStyle = DataGridViewCellStyle3
        Me.ItemsOrdered.HeaderText = "Items Ordered"
        Me.ItemsOrdered.MinimumWidth = 6
        Me.ItemsOrdered.Name = "ItemsOrdered"
        Me.ItemsOrdered.ReadOnly = True
        Me.ItemsOrdered.Width = 75
        '
        'OrderTotal
        '
        Me.OrderTotal.DataPropertyName = "OrderTotal"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.Format = "C2"
        DataGridViewCellStyle4.NullValue = Nothing
        Me.OrderTotal.DefaultCellStyle = DataGridViewCellStyle4
        Me.OrderTotal.HeaderText = "Order Total"
        Me.OrderTotal.MinimumWidth = 6
        Me.OrderTotal.Name = "OrderTotal"
        Me.OrderTotal.ReadOnly = True
        Me.OrderTotal.Width = 75
        '
        'lblAvgTotalTitle
        '
        Me.lblAvgTotalTitle.AutoSize = True
        Me.lblAvgTotalTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvgTotalTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblAvgTotalTitle.Location = New System.Drawing.Point(524, 518)
        Me.lblAvgTotalTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAvgTotalTitle.Name = "lblAvgTotalTitle"
        Me.lblAvgTotalTitle.Size = New System.Drawing.Size(174, 22)
        Me.lblAvgTotalTitle.TabIndex = 18
        Me.lblAvgTotalTitle.Text = "Average Order Total"
        '
        'lblTotalTitle
        '
        Me.lblTotalTitle.AutoSize = True
        Me.lblTotalTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblTotalTitle.Location = New System.Drawing.Point(502, 545)
        Me.lblTotalTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotalTitle.Name = "lblTotalTitle"
        Me.lblTotalTitle.Size = New System.Drawing.Size(196, 22)
        Me.lblTotalTitle.TabIndex = 19
        Me.lblTotalTitle.Text = "Cumulative Order Total"
        '
        'lblQuantityTitle
        '
        Me.lblQuantityTitle.AutoSize = True
        Me.lblQuantityTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantityTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblQuantityTitle.Location = New System.Drawing.Point(217, 518)
        Me.lblQuantityTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblQuantityTitle.Name = "lblQuantityTitle"
        Me.lblQuantityTitle.Size = New System.Drawing.Size(157, 22)
        Me.lblQuantityTitle.TabIndex = 20
        Me.lblQuantityTitle.Text = "Quantity of Orders"
        '
        'lblTotalQuantityTitle
        '
        Me.lblTotalQuantityTitle.AutoSize = True
        Me.lblTotalQuantityTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalQuantityTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblTotalQuantityTitle.Location = New System.Drawing.Point(206, 545)
        Me.lblTotalQuantityTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotalQuantityTitle.Name = "lblTotalQuantityTitle"
        Me.lblTotalQuantityTitle.Size = New System.Drawing.Size(169, 22)
        Me.lblTotalQuantityTitle.TabIndex = 21
        Me.lblTotalQuantityTitle.Text = "Total Items Ordered"
        '
        'lblQuantity
        '
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.ForeColor = System.Drawing.Color.FromArgb(CType(CType(117, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.lblQuantity.Location = New System.Drawing.Point(378, 518)
        Me.lblQuantity.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(20, 22)
        Me.lblQuantity.TabIndex = 22
        Me.lblQuantity.Text = "0"
        '
        'lblTotalItems
        '
        Me.lblTotalItems.AutoSize = True
        Me.lblTotalItems.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalItems.ForeColor = System.Drawing.Color.FromArgb(CType(CType(117, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.lblTotalItems.Location = New System.Drawing.Point(378, 545)
        Me.lblTotalItems.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotalItems.Name = "lblTotalItems"
        Me.lblTotalItems.Size = New System.Drawing.Size(20, 22)
        Me.lblTotalItems.TabIndex = 23
        Me.lblTotalItems.Text = "0"
        '
        'lblAvgTotal
        '
        Me.lblAvgTotal.AutoSize = True
        Me.lblAvgTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvgTotal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(117, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.lblAvgTotal.Location = New System.Drawing.Point(701, 518)
        Me.lblAvgTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAvgTotal.Name = "lblAvgTotal"
        Me.lblAvgTotal.Size = New System.Drawing.Size(55, 22)
        Me.lblAvgTotal.TabIndex = 24
        Me.lblAvgTotal.Text = "$0.00"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(117, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.lblTotal.Location = New System.Drawing.Point(701, 545)
        Me.lblTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(55, 22)
        Me.lblTotal.TabIndex = 25
        Me.lblTotal.Text = "$0.00"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrderSearchToolStripMenuItem, Me.ManagementToolStripMenuItem, Me.ManagementToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(3, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(966, 26)
        Me.MenuStrip1.TabIndex = 26
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'OrderSearchToolStripMenuItem
        '
        Me.OrderSearchToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.OrderSearchToolStripMenuItem.Name = "OrderSearchToolStripMenuItem"
        Me.OrderSearchToolStripMenuItem.Size = New System.Drawing.Size(107, 24)
        Me.OrderSearchToolStripMenuItem.Text = "Order Search"
        '
        'ManagementToolStripMenuItem
        '
        Me.ManagementToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrdersToolStripMenuItem, Me.CustomersToolStripMenuItem})
        Me.ManagementToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.ManagementToolStripMenuItem.Name = "ManagementToolStripMenuItem"
        Me.ManagementToolStripMenuItem.Size = New System.Drawing.Size(119, 24)
        Me.ManagementToolStripMenuItem.Text = "Front of House"
        '
        'OrdersToolStripMenuItem
        '
        Me.OrdersToolStripMenuItem.Name = "OrdersToolStripMenuItem"
        Me.OrdersToolStripMenuItem.Size = New System.Drawing.Size(147, 24)
        Me.OrdersToolStripMenuItem.Text = "Orders"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(147, 24)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'ManagementToolStripMenuItem1
        '
        Me.ManagementToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RewardStatusToolStripMenuItem})
        Me.ManagementToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.ManagementToolStripMenuItem1.Name = "ManagementToolStripMenuItem1"
        Me.ManagementToolStripMenuItem1.Size = New System.Drawing.Size(109, 24)
        Me.ManagementToolStripMenuItem1.Text = "Management"
        '
        'RewardStatusToolStripMenuItem
        '
        Me.RewardStatusToolStripMenuItem.Name = "RewardStatusToolStripMenuItem"
        Me.RewardStatusToolStripMenuItem.Size = New System.Drawing.Size(172, 24)
        Me.RewardStatusToolStripMenuItem.Text = "Reward Status"
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.btnClose.Location = New System.Drawing.Point(901, 32)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(2)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(51, 27)
        Me.btnClose.TabIndex = 27
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'OrderSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(966, 593)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblAvgTotal)
        Me.Controls.Add(Me.lblTotalItems)
        Me.Controls.Add(Me.lblQuantity)
        Me.Controls.Add(Me.lblTotalQuantityTitle)
        Me.Controls.Add(Me.lblQuantityTitle)
        Me.Controls.Add(Me.lblTotalTitle)
        Me.Controls.Add(Me.lblAvgTotalTitle)
        Me.Controls.Add(Me.OrderSearchDataGridView)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.cbEmpAll)
        Me.Controls.Add(Me.lblEmployee)
        Me.Controls.Add(Me.cboEmployee)
        Me.Controls.Add(Me.lblOrderFulfillment)
        Me.Controls.Add(Me.cboOrderFulfillment)
        Me.Controls.Add(Me.lblOrderPlacement)
        Me.Controls.Add(Me.cboOrderPlacement)
        Me.Controls.Add(Me.lblLocation)
        Me.Controls.Add(Me.cboLocation)
        Me.Controls.Add(Me.lblBeginDate)
        Me.Controls.Add(Me.lblEndDate)
        Me.Controls.Add(Me.dtEndDate)
        Me.Controls.Add(Me.dtBeginDate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Name = "OrderSearch"
        Me.Text = "OrderSearch"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StoreLocationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BackToRootsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderPlacementBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderFulfillmentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BackToRootsDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderSearchBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderSearchDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents dtBeginDate As DateTimePicker
    Friend WithEvents dtEndDate As DateTimePicker
    Friend WithEvents lblEndDate As Label
    Friend WithEvents lblBeginDate As Label
    Friend WithEvents cboLocation As ComboBox
    Friend WithEvents BackToRootsDataSet As BackToRootsDataSet
    Friend WithEvents StoreLocationBindingSource As BindingSource
    Friend WithEvents StoreLocationTableAdapter As BackToRootsDataSetTableAdapters.StoreLocationTableAdapter
    Friend WithEvents lblLocation As Label
    Friend WithEvents cboOrderPlacement As ComboBox
    Friend WithEvents lblOrderPlacement As Label
    Friend WithEvents cboOrderFulfillment As ComboBox
    Friend WithEvents lblOrderFulfillment As Label
    Friend WithEvents OrderPlacementBindingSource As BindingSource
    Friend WithEvents OrderPlacementTableAdapter As BackToRootsDataSetTableAdapters.OrderPlacementTableAdapter
    Friend WithEvents OrderFulfillmentBindingSource As BindingSource
    Friend WithEvents OrderFulfillmentTableAdapter As BackToRootsDataSetTableAdapters.OrderFulfillmentTableAdapter
    Friend WithEvents cboEmployee As ComboBox
    Friend WithEvents BackToRootsDataSet1 As BackToRootsDataSet
    Friend WithEvents EmployeeBindingSource As BindingSource
    Friend WithEvents EmployeeTableAdapter As BackToRootsDataSetTableAdapters.EmployeeTableAdapter
    Friend WithEvents lblEmployee As Label
    Friend WithEvents cbEmpAll As CheckBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents OrderSearchBindingSource As BindingSource
    Friend WithEvents OrderSearchTableAdapter As BackToRootsDataSetTableAdapters.OrderSearchTableAdapter
    Friend WithEvents TableAdapterManager As BackToRootsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents OrderSearchDataGridView As DataGridView
    Friend WithEvents EmployeeBindingSource1 As BindingSource
    Friend WithEvents lblAvgTotalTitle As Label
    Friend WithEvents lblTotalTitle As Label
    Friend WithEvents lblQuantityTitle As Label
    Friend WithEvents lblTotalQuantityTitle As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents lblTotalItems As Label
    Friend WithEvents lblAvgTotal As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents OrderSearchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagementToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrdersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagementToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RewardStatusToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnClose As Button
    Friend WithEvents OrderID As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents CustomerName As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents LineItems As DataGridViewTextBoxColumn
    Friend WithEvents ItemsOrdered As DataGridViewTextBoxColumn
    Friend WithEvents OrderTotal As DataGridViewTextBoxColumn
End Class
