-- BackToRoots Database Report Queries Written by Hannah McDonald
-- Originally Written: May 25, 2021 | Updated: May 2021
---------------------------------------------------------------
USE BackToRoots
GO
---------------------------------------------------------------
-- Select the appropriate data for the ProductSales Report
SELECT 
	YEAR(CustomerOrder.OrderDate) AS 'Year',
	MONTH(CustomerOrder.OrderDate) AS 'MonthSort',
	DATENAME(month, CustomerOrder.OrderDate) AS 'Month',
	CustomerOrder.LocationID, 
	ProductType.ProductTypeName, 
	Product.ProductName, 
	OrderLine.Quantity,
	OrderLine.Quantity*Product.ProductPrice AS Sales
FROM  CustomerOrder 
INNER JOIN OrderLine 
	ON CustomerOrder.OrderID = OrderLine.OrderID 
INNER JOIN Product 
	ON OrderLine.ProductID = Product.ProductID 
INNER JOIN ProductType 
	ON Product.ProductTypeID = ProductType.ProductTypeID;
--WHERE (CustomerOrder.LocationID IN (@Location)) AND (YEAR(CustomerOrder.OrderDate) = @Year);
---------------------------------------------------------------
-- Select the appropriate data for the EmployeePerformance Report
SELECT
	EmploymentHistory.WageType,
	Position.PositionName,
	(Employee.EmployeeFirstName + ' ' + Employee.EmployeeLastName) AS 'EmployeeName',
	EmploymentHistory.Wage,
	IIF(EmploymentHistory.EndDate IS NULL, 'Current', 'End Dated') AS 'PositionStatus',
	COUNT(DISTINCT CustomerOrder.OrderDate) AS 'DaysWorked',
	COUNT(DISTINCT CustomerOrder.OrderID) AS 'OrdersFilled',
	SUM(OrderLine.Quantity*Product.ProductPrice) AS 'Sales'
FROM Position
INNER JOIN EmploymentHistory
	ON Position.PositionID = EmploymentHistory.PositionID
INNER JOIN Employee
	ON Employee.EmployeeID = EmploymentHistory.EmployeeID
INNER JOIN CustomerOrder
	ON Employee.EmployeeID = CustomerOrder.EmployeeID
INNER JOIN OrderLine
	ON CustomerOrder.OrderID = OrderLine.OrderID
INNER JOIN Product
	ON Product.ProductID = OrderLine.ProductID
WHERE 
	CustomerOrder.OrderDate BETWEEN EmploymentHistory.HireDate AND IIF(EmploymentHistory.EndDate IS NULL, GetDate(), EmploymentHistory.EndDate)
	-- AND CustomerOrder.OrderDate BETWEEN @ReportStartDate AND @ReportEndDate
GROUP BY
	Position.PositionName,
	EmploymentHistory.WageType,
	(Employee.EmployeeFirstName + ' ' + Employee.EmployeeLastName),
	EmploymentHistory.Wage,
	IIF(EmploymentHistory.EndDate IS NULL, 'Current', 'End Dated');
---------------------------------------------------------------