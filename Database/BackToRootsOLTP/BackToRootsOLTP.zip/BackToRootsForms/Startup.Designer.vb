﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Startup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Startup))
        Me.lblCustomers = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnOrderSearch = New System.Windows.Forms.Button()
        Me.btnRewardStatus = New System.Windows.Forms.Button()
        Me.btnCustomers = New System.Windows.Forms.Button()
        Me.btnOrders = New System.Windows.Forms.Button()
        Me.GroupBoxFOH = New System.Windows.Forms.GroupBox()
        Me.GroupBoxManagement = New System.Windows.Forms.GroupBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.OrderSearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrdersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagementToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RewardStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnClose = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxFOH.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblCustomers
        '
        Me.lblCustomers.AutoSize = True
        Me.lblCustomers.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomers.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblCustomers.Location = New System.Drawing.Point(353, 203)
        Me.lblCustomers.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCustomers.Name = "lblCustomers"
        Me.lblCustomers.Size = New System.Drawing.Size(641, 63)
        Me.lblCustomers.TabIndex = 11
        Me.lblCustomers.Text = "INFORMATION SYSTEM"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(321, 115)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(705, 76)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Back-to-Roots Bakery"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(1081, 92)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(236, 320)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'btnOrderSearch
        '
        Me.btnOrderSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrderSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.btnOrderSearch.Location = New System.Drawing.Point(538, 317)
        Me.btnOrderSearch.Name = "btnOrderSearch"
        Me.btnOrderSearch.Size = New System.Drawing.Size(270, 81)
        Me.btnOrderSearch.TabIndex = 0
        Me.btnOrderSearch.Text = "Order Search"
        Me.btnOrderSearch.UseVisualStyleBackColor = True
        '
        'btnRewardStatus
        '
        Me.btnRewardStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRewardStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.btnRewardStatus.Location = New System.Drawing.Point(761, 495)
        Me.btnRewardStatus.Name = "btnRewardStatus"
        Me.btnRewardStatus.Size = New System.Drawing.Size(270, 81)
        Me.btnRewardStatus.TabIndex = 3
        Me.btnRewardStatus.Text = "Reward Status"
        Me.btnRewardStatus.UseVisualStyleBackColor = True
        '
        'btnCustomers
        '
        Me.btnCustomers.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCustomers.Location = New System.Drawing.Point(41, 157)
        Me.btnCustomers.Name = "btnCustomers"
        Me.btnCustomers.Size = New System.Drawing.Size(270, 81)
        Me.btnCustomers.TabIndex = 1
        Me.btnCustomers.Text = "Customers"
        Me.btnCustomers.UseVisualStyleBackColor = True
        '
        'btnOrders
        '
        Me.btnOrders.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrders.Location = New System.Drawing.Point(41, 52)
        Me.btnOrders.Name = "btnOrders"
        Me.btnOrders.Size = New System.Drawing.Size(270, 81)
        Me.btnOrders.TabIndex = 0
        Me.btnOrders.Text = "Orders"
        Me.btnOrders.UseVisualStyleBackColor = True
        '
        'GroupBoxFOH
        '
        Me.GroupBoxFOH.Controls.Add(Me.btnOrders)
        Me.GroupBoxFOH.Controls.Add(Me.btnCustomers)
        Me.GroupBoxFOH.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxFOH.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.GroupBoxFOH.Location = New System.Drawing.Point(270, 443)
        Me.GroupBoxFOH.Name = "GroupBoxFOH"
        Me.GroupBoxFOH.Size = New System.Drawing.Size(358, 274)
        Me.GroupBoxFOH.TabIndex = 1
        Me.GroupBoxFOH.TabStop = False
        Me.GroupBoxFOH.Text = "Front of House"
        '
        'GroupBoxManagement
        '
        Me.GroupBoxManagement.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxManagement.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.GroupBoxManagement.Location = New System.Drawing.Point(718, 443)
        Me.GroupBoxManagement.Name = "GroupBoxManagement"
        Me.GroupBoxManagement.Size = New System.Drawing.Size(358, 274)
        Me.GroupBoxManagement.TabIndex = 2
        Me.GroupBoxManagement.TabStop = False
        Me.GroupBoxManagement.Text = "Management"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrderSearchToolStripMenuItem, Me.ManagementToolStripMenuItem, Me.ManagementToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1346, 49)
        Me.MenuStrip1.TabIndex = 18
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'OrderSearchToolStripMenuItem
        '
        Me.OrderSearchToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.OrderSearchToolStripMenuItem.Name = "OrderSearchToolStripMenuItem"
        Me.OrderSearchToolStripMenuItem.Size = New System.Drawing.Size(211, 45)
        Me.OrderSearchToolStripMenuItem.Text = "Order Search"
        '
        'ManagementToolStripMenuItem
        '
        Me.ManagementToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrdersToolStripMenuItem, Me.CustomersToolStripMenuItem})
        Me.ManagementToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.ManagementToolStripMenuItem.Name = "ManagementToolStripMenuItem"
        Me.ManagementToolStripMenuItem.Size = New System.Drawing.Size(236, 45)
        Me.ManagementToolStripMenuItem.Text = "Front of House"
        '
        'OrdersToolStripMenuItem
        '
        Me.OrdersToolStripMenuItem.Name = "OrdersToolStripMenuItem"
        Me.OrdersToolStripMenuItem.Size = New System.Drawing.Size(297, 50)
        Me.OrdersToolStripMenuItem.Text = "Orders"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(297, 50)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'ManagementToolStripMenuItem1
        '
        Me.ManagementToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RewardStatusToolStripMenuItem})
        Me.ManagementToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.ManagementToolStripMenuItem1.Name = "ManagementToolStripMenuItem1"
        Me.ManagementToolStripMenuItem1.Size = New System.Drawing.Size(215, 45)
        Me.ManagementToolStripMenuItem1.Text = "Management"
        '
        'RewardStatusToolStripMenuItem
        '
        Me.RewardStatusToolStripMenuItem.Name = "RewardStatusToolStripMenuItem"
        Me.RewardStatusToolStripMenuItem.Size = New System.Drawing.Size(341, 50)
        Me.RewardStatusToolStripMenuItem.Text = "Reward Status"
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.btnClose.Location = New System.Drawing.Point(1232, 61)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(102, 51)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Startup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1346, 790)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnRewardStatus)
        Me.Controls.Add(Me.btnOrderSearch)
        Me.Controls.Add(Me.lblCustomers)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBoxFOH)
        Me.Controls.Add(Me.GroupBoxManagement)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Startup"
        Me.Text = "Back-to-Roots"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxFOH.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCustomers As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnOrderSearch As Button
    Friend WithEvents btnRewardStatus As Button
    Friend WithEvents btnCustomers As Button
    Friend WithEvents btnOrders As Button
    Friend WithEvents GroupBoxFOH As GroupBox
    Friend WithEvents GroupBoxManagement As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents OrderSearchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagementToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrdersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagementToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RewardStatusToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnClose As Button
End Class
