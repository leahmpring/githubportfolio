﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Orders
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim lblOrderDetails As System.Windows.Forms.Label
        Dim lblOrderID As System.Windows.Forms.Label
        Dim lblEmployee As System.Windows.Forms.Label
        Dim lblLocation As System.Windows.Forms.Label
        Dim lblCustomer As System.Windows.Forms.Label
        Dim lblOrderDate As System.Windows.Forms.Label
        Dim lblOrderPlacement As System.Windows.Forms.Label
        Dim lblOrderFulfillment As System.Windows.Forms.Label
        Dim lblOrderTotalTitle As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Orders))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BackToRootsDataSet = New BackToRootsForms.BackToRootsDataSet()
        Me.CustomerOrderBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerOrderTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.CustomerOrderTableAdapter()
        Me.TableAdapterManager = New BackToRootsForms.BackToRootsDataSetTableAdapters.TableAdapterManager()
        Me.CustomerTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.CustomerTableAdapter()
        Me.EmployeeTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.EmployeeTableAdapter()
        Me.OrderLineTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderLineTableAdapter()
        Me.StoreLocationTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.StoreLocationTableAdapter()
        Me.CustomerOrderBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CustomerOrderBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.OrderIDTextBox = New System.Windows.Forms.TextBox()
        Me.cboEmployee = New System.Windows.Forms.ComboBox()
        Me.EmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboLocation = New System.Windows.Forms.ComboBox()
        Me.StoreLocationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboCustomer = New System.Windows.Forms.ComboBox()
        Me.CustomerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.dtOrderDate = New System.Windows.Forms.DateTimePicker()
        Me.cboOrderPlacement = New System.Windows.Forms.ComboBox()
        Me.OrderPlacementBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboOrderFulfillment = New System.Windows.Forms.ComboBox()
        Me.OrderFulfillmentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrderLineBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrderLineDataGridView = New System.Windows.Forms.DataGridView()
        Me.ProductBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BackToRootsDataSet1 = New BackToRootsForms.BackToRootsDataSet()
        Me.FillBy1ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.OrderIDToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.txtOrderIDToolStrip = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripOrder = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripFillAllOrders = New System.Windows.Forms.ToolStripButton()
        Me.lblOrderTotal = New System.Windows.Forms.Label()
        Me.ProductTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.ProductTableAdapter()
        Me.btnCustomerInfo = New System.Windows.Forms.Button()
        Me.OrderPlacementTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderPlacementTableAdapter()
        Me.OrderFulfillmentTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderFulfillmentTableAdapter()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.OrderSearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrdersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagementToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RewardStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.LineItem = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductID = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LineTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        lblOrderDetails = New System.Windows.Forms.Label()
        lblOrderID = New System.Windows.Forms.Label()
        lblEmployee = New System.Windows.Forms.Label()
        lblLocation = New System.Windows.Forms.Label()
        lblCustomer = New System.Windows.Forms.Label()
        lblOrderDate = New System.Windows.Forms.Label()
        lblOrderPlacement = New System.Windows.Forms.Label()
        lblOrderFulfillment = New System.Windows.Forms.Label()
        lblOrderTotalTitle = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BackToRootsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerOrderBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerOrderBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CustomerOrderBindingNavigator.SuspendLayout()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StoreLocationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderPlacementBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderFulfillmentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderLineBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderLineDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProductBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BackToRootsDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillBy1ToolStrip.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblOrderDetails
        '
        lblOrderDetails.AutoSize = True
        lblOrderDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        lblOrderDetails.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblOrderDetails.Location = New System.Drawing.Point(126, 330)
        lblOrderDetails.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblOrderDetails.Name = "lblOrderDetails"
        lblOrderDetails.Size = New System.Drawing.Size(116, 22)
        lblOrderDetails.TabIndex = 15
        lblOrderDetails.Text = "Order Details"
        '
        'lblOrderID
        '
        lblOrderID.AutoSize = True
        lblOrderID.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        lblOrderID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblOrderID.Location = New System.Drawing.Point(113, 174)
        lblOrderID.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblOrderID.Name = "lblOrderID"
        lblOrderID.Size = New System.Drawing.Size(78, 22)
        lblOrderID.TabIndex = 0
        lblOrderID.Text = "Order ID"
        '
        'lblEmployee
        '
        lblEmployee.AutoSize = True
        lblEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        lblEmployee.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblEmployee.Location = New System.Drawing.Point(113, 241)
        lblEmployee.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblEmployee.Name = "lblEmployee"
        lblEmployee.Size = New System.Drawing.Size(89, 22)
        lblEmployee.TabIndex = 4
        lblEmployee.Text = "Employee"
        '
        'lblLocation
        '
        lblLocation.AutoSize = True
        lblLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        lblLocation.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblLocation.Location = New System.Drawing.Point(113, 206)
        lblLocation.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblLocation.Name = "lblLocation"
        lblLocation.Size = New System.Drawing.Size(78, 22)
        lblLocation.TabIndex = 2
        lblLocation.Text = "Location"
        '
        'lblCustomer
        '
        lblCustomer.AutoSize = True
        lblCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        lblCustomer.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomer.Location = New System.Drawing.Point(113, 276)
        lblCustomer.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomer.Name = "lblCustomer"
        lblCustomer.Size = New System.Drawing.Size(87, 22)
        lblCustomer.TabIndex = 6
        lblCustomer.Text = "Customer"
        '
        'lblOrderDate
        '
        lblOrderDate.AutoSize = True
        lblOrderDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        lblOrderDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblOrderDate.Location = New System.Drawing.Point(439, 174)
        lblOrderDate.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblOrderDate.Name = "lblOrderDate"
        lblOrderDate.Size = New System.Drawing.Size(99, 22)
        lblOrderDate.TabIndex = 9
        lblOrderDate.Text = "Order Date"
        '
        'lblOrderPlacement
        '
        lblOrderPlacement.AutoSize = True
        lblOrderPlacement.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        lblOrderPlacement.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblOrderPlacement.Location = New System.Drawing.Point(439, 241)
        lblOrderPlacement.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblOrderPlacement.Name = "lblOrderPlacement"
        lblOrderPlacement.Size = New System.Drawing.Size(145, 22)
        lblOrderPlacement.TabIndex = 11
        lblOrderPlacement.Text = "Order Placement"
        '
        'lblOrderFulfillment
        '
        lblOrderFulfillment.AutoSize = True
        lblOrderFulfillment.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        lblOrderFulfillment.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblOrderFulfillment.Location = New System.Drawing.Point(439, 276)
        lblOrderFulfillment.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblOrderFulfillment.Name = "lblOrderFulfillment"
        lblOrderFulfillment.Size = New System.Drawing.Size(142, 22)
        lblOrderFulfillment.TabIndex = 13
        lblOrderFulfillment.Text = "Order Fulfillment"
        '
        'lblOrderTotalTitle
        '
        lblOrderTotalTitle.AutoSize = True
        lblOrderTotalTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        lblOrderTotalTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblOrderTotalTitle.Location = New System.Drawing.Point(520, 542)
        lblOrderTotalTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblOrderTotalTitle.Name = "lblOrderTotalTitle"
        lblOrderTotalTitle.Size = New System.Drawing.Size(111, 25)
        lblOrderTotalTitle.TabIndex = 17
        lblOrderTotalTitle.Text = "Order Total"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(353, 121)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 31)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "ORDERS"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(248, 82)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(367, 39)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Back-to-Roots Bakery"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(706, 44)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(118, 166)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'BackToRootsDataSet
        '
        Me.BackToRootsDataSet.DataSetName = "BackToRootsDataSet"
        Me.BackToRootsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CustomerOrderBindingSource
        '
        Me.CustomerOrderBindingSource.DataMember = "CustomerOrder"
        Me.CustomerOrderBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'CustomerOrderTableAdapter
        '
        Me.CustomerOrderTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CustomerOrderTableAdapter = Me.CustomerOrderTableAdapter
        Me.TableAdapterManager.CustomerTableAdapter = Me.CustomerTableAdapter
        Me.TableAdapterManager.DietProductTableAdapter = Nothing
        Me.TableAdapterManager.DietTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Me.EmployeeTableAdapter
        Me.TableAdapterManager.EmploymentHistoryTableAdapter = Nothing
        Me.TableAdapterManager.OrderLineTableAdapter = Me.OrderLineTableAdapter
        Me.TableAdapterManager.PositionTableAdapter = Nothing
        Me.TableAdapterManager.ProductTableAdapter = Nothing
        Me.TableAdapterManager.ProductTypeTableAdapter = Nothing
        Me.TableAdapterManager.RewardHistoryTableAdapter = Nothing
        Me.TableAdapterManager.RewardStatusTableAdapter = Nothing
        Me.TableAdapterManager.StoreLocationTableAdapter = Me.StoreLocationTableAdapter
        Me.TableAdapterManager.UpdateOrder = BackToRootsForms.BackToRootsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CustomerTableAdapter
        '
        Me.CustomerTableAdapter.ClearBeforeFill = True
        '
        'EmployeeTableAdapter
        '
        Me.EmployeeTableAdapter.ClearBeforeFill = True
        '
        'OrderLineTableAdapter
        '
        Me.OrderLineTableAdapter.ClearBeforeFill = True
        '
        'StoreLocationTableAdapter
        '
        Me.StoreLocationTableAdapter.ClearBeforeFill = True
        '
        'CustomerOrderBindingNavigator
        '
        Me.CustomerOrderBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.CustomerOrderBindingNavigator.BindingSource = Me.CustomerOrderBindingSource
        Me.CustomerOrderBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.CustomerOrderBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.CustomerOrderBindingNavigator.Dock = System.Windows.Forms.DockStyle.None
        Me.CustomerOrderBindingNavigator.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.CustomerOrderBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.CustomerOrderBindingNavigatorSaveItem})
        Me.CustomerOrderBindingNavigator.Location = New System.Drawing.Point(7, 36)
        Me.CustomerOrderBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.CustomerOrderBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.CustomerOrderBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.CustomerOrderBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.CustomerOrderBindingNavigator.Name = "CustomerOrderBindingNavigator"
        Me.CustomerOrderBindingNavigator.Padding = New System.Windows.Forms.Padding(0, 0, 2, 0)
        Me.CustomerOrderBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.CustomerOrderBindingNavigator.Size = New System.Drawing.Size(293, 27)
        Me.CustomerOrderBindingNavigator.TabIndex = 35
        Me.CustomerOrderBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 24)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Enabled = False
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(57, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 27)
        '
        'CustomerOrderBindingNavigatorSaveItem
        '
        Me.CustomerOrderBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CustomerOrderBindingNavigatorSaveItem.Image = CType(resources.GetObject("CustomerOrderBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.CustomerOrderBindingNavigatorSaveItem.Name = "CustomerOrderBindingNavigatorSaveItem"
        Me.CustomerOrderBindingNavigatorSaveItem.Size = New System.Drawing.Size(24, 24)
        Me.CustomerOrderBindingNavigatorSaveItem.Text = "Save Data"
        '
        'OrderIDTextBox
        '
        Me.OrderIDTextBox.BackColor = System.Drawing.Color.LightGray
        Me.OrderIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerOrderBindingSource, "OrderID", True))
        Me.OrderIDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrderIDTextBox.Location = New System.Drawing.Point(204, 171)
        Me.OrderIDTextBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.OrderIDTextBox.Name = "OrderIDTextBox"
        Me.OrderIDTextBox.ReadOnly = True
        Me.OrderIDTextBox.Size = New System.Drawing.Size(118, 27)
        Me.OrderIDTextBox.TabIndex = 1
        '
        'cboEmployee
        '
        Me.cboEmployee.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.CustomerOrderBindingSource, "EmployeeID", True))
        Me.cboEmployee.DataSource = Me.EmployeeBindingSource
        Me.cboEmployee.DisplayMember = "EmployeeFullName"
        Me.cboEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboEmployee.FormattingEnabled = True
        Me.cboEmployee.Location = New System.Drawing.Point(204, 238)
        Me.cboEmployee.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboEmployee.Name = "cboEmployee"
        Me.cboEmployee.Size = New System.Drawing.Size(214, 28)
        Me.cboEmployee.TabIndex = 5
        Me.cboEmployee.ValueMember = "EmployeeID"
        '
        'EmployeeBindingSource
        '
        Me.EmployeeBindingSource.DataMember = "Employee"
        Me.EmployeeBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'cboLocation
        '
        Me.cboLocation.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.CustomerOrderBindingSource, "LocationID", True))
        Me.cboLocation.DataSource = Me.StoreLocationBindingSource
        Me.cboLocation.DisplayMember = "LocationCity"
        Me.cboLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboLocation.FormattingEnabled = True
        Me.cboLocation.Location = New System.Drawing.Point(204, 203)
        Me.cboLocation.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboLocation.Name = "cboLocation"
        Me.cboLocation.Size = New System.Drawing.Size(118, 28)
        Me.cboLocation.TabIndex = 3
        Me.cboLocation.ValueMember = "LocationID"
        '
        'StoreLocationBindingSource
        '
        Me.StoreLocationBindingSource.DataMember = "StoreLocation"
        Me.StoreLocationBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'cboCustomer
        '
        Me.cboCustomer.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.CustomerOrderBindingSource, "CustomerID", True))
        Me.cboCustomer.DataSource = Me.CustomerBindingSource
        Me.cboCustomer.DisplayMember = "CustomerFullName"
        Me.cboCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCustomer.FormattingEnabled = True
        Me.cboCustomer.Location = New System.Drawing.Point(204, 273)
        Me.cboCustomer.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.Size = New System.Drawing.Size(214, 28)
        Me.cboCustomer.TabIndex = 7
        Me.cboCustomer.ValueMember = "CustomerID"
        '
        'CustomerBindingSource
        '
        Me.CustomerBindingSource.DataMember = "Customer"
        Me.CustomerBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'dtOrderDate
        '
        Me.dtOrderDate.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.CustomerOrderBindingSource, "OrderDate", True))
        Me.dtOrderDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtOrderDate.Location = New System.Drawing.Point(442, 204)
        Me.dtOrderDate.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.dtOrderDate.Name = "dtOrderDate"
        Me.dtOrderDate.Size = New System.Drawing.Size(284, 27)
        Me.dtOrderDate.TabIndex = 10
        '
        'cboOrderPlacement
        '
        Me.cboOrderPlacement.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.CustomerOrderBindingSource, "OrderPlacement", True))
        Me.cboOrderPlacement.DataSource = Me.OrderPlacementBindingSource
        Me.cboOrderPlacement.DisplayMember = "OrderPlacement"
        Me.cboOrderPlacement.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboOrderPlacement.FormattingEnabled = True
        Me.cboOrderPlacement.Location = New System.Drawing.Point(584, 238)
        Me.cboOrderPlacement.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboOrderPlacement.Name = "cboOrderPlacement"
        Me.cboOrderPlacement.Size = New System.Drawing.Size(144, 28)
        Me.cboOrderPlacement.TabIndex = 12
        Me.cboOrderPlacement.ValueMember = "OrderPlacement"
        '
        'OrderPlacementBindingSource
        '
        Me.OrderPlacementBindingSource.DataMember = "OrderPlacement"
        Me.OrderPlacementBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'cboOrderFulfillment
        '
        Me.cboOrderFulfillment.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.CustomerOrderBindingSource, "OrderFulfillment", True))
        Me.cboOrderFulfillment.DataSource = Me.OrderFulfillmentBindingSource
        Me.cboOrderFulfillment.DisplayMember = "OrderFulfillment"
        Me.cboOrderFulfillment.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboOrderFulfillment.FormattingEnabled = True
        Me.cboOrderFulfillment.Location = New System.Drawing.Point(584, 273)
        Me.cboOrderFulfillment.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.cboOrderFulfillment.Name = "cboOrderFulfillment"
        Me.cboOrderFulfillment.Size = New System.Drawing.Size(144, 28)
        Me.cboOrderFulfillment.TabIndex = 14
        Me.cboOrderFulfillment.ValueMember = "OrderFulfillment"
        '
        'OrderFulfillmentBindingSource
        '
        Me.OrderFulfillmentBindingSource.DataMember = "OrderFulfillment"
        Me.OrderFulfillmentBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'OrderLineBindingSource
        '
        Me.OrderLineBindingSource.DataMember = "fk_order_line_order_id"
        Me.OrderLineBindingSource.DataSource = Me.CustomerOrderBindingSource
        '
        'OrderLineDataGridView
        '
        Me.OrderLineDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.OrderLineDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.OrderLineDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.OrderLineDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LineItem, Me.ProductID, Me.DataGridViewTextBoxColumn3, Me.ProductPrice, Me.LineTotal})
        Me.OrderLineDataGridView.DataSource = Me.OrderLineBindingSource
        Me.OrderLineDataGridView.Location = New System.Drawing.Point(118, 361)
        Me.OrderLineDataGridView.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.OrderLineDataGridView.Name = "OrderLineDataGridView"
        Me.OrderLineDataGridView.RowHeadersWidth = 51
        Me.OrderLineDataGridView.RowTemplate.Height = 24
        Me.OrderLineDataGridView.Size = New System.Drawing.Size(613, 164)
        Me.OrderLineDataGridView.TabIndex = 16
        '
        'ProductBindingSource
        '
        Me.ProductBindingSource.DataMember = "Product"
        Me.ProductBindingSource.DataSource = Me.BackToRootsDataSet1
        '
        'BackToRootsDataSet1
        '
        Me.BackToRootsDataSet1.DataSetName = "BackToRootsDataSet"
        Me.BackToRootsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'FillBy1ToolStrip
        '
        Me.FillBy1ToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.FillBy1ToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.FillBy1ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrderIDToolStripLabel, Me.txtOrderIDToolStrip, Me.FillByToolStripOrder, Me.ToolStripFillAllOrders})
        Me.FillBy1ToolStrip.Location = New System.Drawing.Point(7, 73)
        Me.FillBy1ToolStrip.Name = "FillBy1ToolStrip"
        Me.FillBy1ToolStrip.Padding = New System.Windows.Forms.Padding(0, 0, 2, 0)
        Me.FillBy1ToolStrip.Size = New System.Drawing.Size(231, 25)
        Me.FillBy1ToolStrip.TabIndex = 49
        Me.FillBy1ToolStrip.Text = "FillBy1ToolStrip"
        '
        'OrderIDToolStripLabel
        '
        Me.OrderIDToolStripLabel.Name = "OrderIDToolStripLabel"
        Me.OrderIDToolStripLabel.Size = New System.Drawing.Size(51, 22)
        Me.OrderIDToolStripLabel.Text = "OrderID:"
        '
        'txtOrderIDToolStrip
        '
        Me.txtOrderIDToolStrip.Name = "txtOrderIDToolStrip"
        Me.txtOrderIDToolStrip.Size = New System.Drawing.Size(76, 25)
        '
        'FillByToolStripOrder
        '
        Me.FillByToolStripOrder.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripOrder.Name = "FillByToolStripOrder"
        Me.FillByToolStripOrder.Size = New System.Drawing.Size(46, 22)
        Me.FillByToolStripOrder.Text = "Search"
        '
        'ToolStripFillAllOrders
        '
        Me.ToolStripFillAllOrders.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripFillAllOrders.Image = CType(resources.GetObject("ToolStripFillAllOrders.Image"), System.Drawing.Image)
        Me.ToolStripFillAllOrders.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripFillAllOrders.Name = "ToolStripFillAllOrders"
        Me.ToolStripFillAllOrders.Size = New System.Drawing.Size(43, 22)
        Me.ToolStripFillAllOrders.Text = "Fill All"
        '
        'lblOrderTotal
        '
        Me.lblOrderTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblOrderTotal.AutoSize = True
        Me.lblOrderTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrderTotal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(117, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.lblOrderTotal.Location = New System.Drawing.Point(643, 542)
        Me.lblOrderTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblOrderTotal.Name = "lblOrderTotal"
        Me.lblOrderTotal.Size = New System.Drawing.Size(61, 25)
        Me.lblOrderTotal.TabIndex = 18
        Me.lblOrderTotal.Text = "$0.00"
        Me.lblOrderTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ProductTableAdapter
        '
        Me.ProductTableAdapter.ClearBeforeFill = True
        '
        'btnCustomerInfo
        '
        Me.btnCustomerInfo.Location = New System.Drawing.Point(318, 305)
        Me.btnCustomerInfo.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.btnCustomerInfo.Name = "btnCustomerInfo"
        Me.btnCustomerInfo.Size = New System.Drawing.Size(99, 23)
        Me.btnCustomerInfo.TabIndex = 8
        Me.btnCustomerInfo.Text = "Customer Details"
        Me.btnCustomerInfo.UseVisualStyleBackColor = True
        '
        'OrderPlacementTableAdapter
        '
        Me.OrderPlacementTableAdapter.ClearBeforeFill = True
        '
        'OrderFulfillmentTableAdapter
        '
        Me.OrderFulfillmentTableAdapter.ClearBeforeFill = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrderSearchToolStripMenuItem, Me.ManagementToolStripMenuItem, Me.ManagementToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(3, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(849, 26)
        Me.MenuStrip1.TabIndex = 50
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'OrderSearchToolStripMenuItem
        '
        Me.OrderSearchToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.OrderSearchToolStripMenuItem.Name = "OrderSearchToolStripMenuItem"
        Me.OrderSearchToolStripMenuItem.Size = New System.Drawing.Size(107, 24)
        Me.OrderSearchToolStripMenuItem.Text = "Order Search"
        '
        'ManagementToolStripMenuItem
        '
        Me.ManagementToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrdersToolStripMenuItem, Me.CustomersToolStripMenuItem})
        Me.ManagementToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.ManagementToolStripMenuItem.Name = "ManagementToolStripMenuItem"
        Me.ManagementToolStripMenuItem.Size = New System.Drawing.Size(119, 24)
        Me.ManagementToolStripMenuItem.Text = "Front of House"
        '
        'OrdersToolStripMenuItem
        '
        Me.OrdersToolStripMenuItem.Name = "OrdersToolStripMenuItem"
        Me.OrdersToolStripMenuItem.Size = New System.Drawing.Size(147, 24)
        Me.OrdersToolStripMenuItem.Text = "Orders"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(147, 24)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'ManagementToolStripMenuItem1
        '
        Me.ManagementToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RewardStatusToolStripMenuItem})
        Me.ManagementToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.ManagementToolStripMenuItem1.Name = "ManagementToolStripMenuItem1"
        Me.ManagementToolStripMenuItem1.Size = New System.Drawing.Size(109, 24)
        Me.ManagementToolStripMenuItem1.Text = "Management"
        '
        'RewardStatusToolStripMenuItem
        '
        Me.RewardStatusToolStripMenuItem.Name = "RewardStatusToolStripMenuItem"
        Me.RewardStatusToolStripMenuItem.Size = New System.Drawing.Size(172, 24)
        Me.RewardStatusToolStripMenuItem.Text = "Reward Status"
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.btnClose.Location = New System.Drawing.Point(782, 31)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(51, 27)
        Me.btnClose.TabIndex = 51
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'LineItem
        '
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGray
        Me.LineItem.DefaultCellStyle = DataGridViewCellStyle2
        Me.LineItem.HeaderText = "Line Item"
        Me.LineItem.MinimumWidth = 6
        Me.LineItem.Name = "LineItem"
        Me.LineItem.ReadOnly = True
        Me.LineItem.Width = 90
        '
        'ProductID
        '
        Me.ProductID.DataPropertyName = "ProductID"
        Me.ProductID.DataSource = Me.ProductBindingSource
        Me.ProductID.DisplayMember = "ProductName"
        Me.ProductID.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ProductID.HeaderText = "Product"
        Me.ProductID.MinimumWidth = 6
        Me.ProductID.Name = "ProductID"
        Me.ProductID.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ProductID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ProductID.ValueMember = "ProductID"
        Me.ProductID.Width = 185
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Quantity"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridViewTextBoxColumn3.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridViewTextBoxColumn3.HeaderText = "Quantity"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 70
        '
        'ProductPrice
        '
        Me.ProductPrice.DataPropertyName = "ProductPrice"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle4.Format = "C2"
        DataGridViewCellStyle4.NullValue = Nothing
        Me.ProductPrice.DefaultCellStyle = DataGridViewCellStyle4
        Me.ProductPrice.HeaderText = "Unit Price"
        Me.ProductPrice.MinimumWidth = 6
        Me.ProductPrice.Name = "ProductPrice"
        Me.ProductPrice.ReadOnly = True
        Me.ProductPrice.Width = 90
        '
        'LineTotal
        '
        Me.LineTotal.DataPropertyName = "LineTotal"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle5.Format = "C2"
        DataGridViewCellStyle5.NullValue = Nothing
        Me.LineTotal.DefaultCellStyle = DataGridViewCellStyle5
        Me.LineTotal.HeaderText = "Line Total"
        Me.LineTotal.MinimumWidth = 6
        Me.LineTotal.Name = "LineTotal"
        Me.LineTotal.ReadOnly = True
        '
        'Orders
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(849, 598)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.btnCustomerInfo)
        Me.Controls.Add(Me.lblOrderTotal)
        Me.Controls.Add(lblOrderTotalTitle)
        Me.Controls.Add(Me.FillBy1ToolStrip)
        Me.Controls.Add(Me.OrderLineDataGridView)
        Me.Controls.Add(Me.OrderIDTextBox)
        Me.Controls.Add(Me.cboEmployee)
        Me.Controls.Add(Me.cboLocation)
        Me.Controls.Add(Me.cboCustomer)
        Me.Controls.Add(Me.dtOrderDate)
        Me.Controls.Add(Me.cboOrderPlacement)
        Me.Controls.Add(Me.cboOrderFulfillment)
        Me.Controls.Add(Me.CustomerOrderBindingNavigator)
        Me.Controls.Add(lblOrderDetails)
        Me.Controls.Add(lblOrderID)
        Me.Controls.Add(lblEmployee)
        Me.Controls.Add(lblLocation)
        Me.Controls.Add(lblCustomer)
        Me.Controls.Add(lblOrderDate)
        Me.Controls.Add(lblOrderPlacement)
        Me.Controls.Add(lblOrderFulfillment)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Name = "Orders"
        Me.Text = "Orders"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BackToRootsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerOrderBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerOrderBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CustomerOrderBindingNavigator.ResumeLayout(False)
        Me.CustomerOrderBindingNavigator.PerformLayout()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StoreLocationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderPlacementBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderFulfillmentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderLineBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderLineDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProductBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BackToRootsDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillBy1ToolStrip.ResumeLayout(False)
        Me.FillBy1ToolStrip.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents BackToRootsDataSet As BackToRootsDataSet
    Friend WithEvents CustomerOrderBindingSource As BindingSource
    Friend WithEvents CustomerOrderTableAdapter As BackToRootsDataSetTableAdapters.CustomerOrderTableAdapter
    Friend WithEvents TableAdapterManager As BackToRootsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CustomerOrderBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents CustomerOrderBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents StoreLocationTableAdapter As BackToRootsDataSetTableAdapters.StoreLocationTableAdapter
    Friend WithEvents OrderIDTextBox As TextBox
    Friend WithEvents cboEmployee As ComboBox
    Friend WithEvents cboLocation As ComboBox
    Friend WithEvents cboCustomer As ComboBox
    Friend WithEvents dtOrderDate As DateTimePicker
    Friend WithEvents cboOrderPlacement As ComboBox
    Friend WithEvents cboOrderFulfillment As ComboBox
    Friend WithEvents StoreLocationBindingSource As BindingSource
    Friend WithEvents CustomerTableAdapter As BackToRootsDataSetTableAdapters.CustomerTableAdapter
    Friend WithEvents CustomerBindingSource As BindingSource
    Friend WithEvents EmployeeTableAdapter As BackToRootsDataSetTableAdapters.EmployeeTableAdapter
    Friend WithEvents EmployeeBindingSource As BindingSource
    Friend WithEvents OrderLineTableAdapter As BackToRootsDataSetTableAdapters.OrderLineTableAdapter
    Friend WithEvents OrderLineBindingSource As BindingSource
    Friend WithEvents OrderLineDataGridView As DataGridView
    Friend WithEvents FillBy1ToolStrip As ToolStrip
    Friend WithEvents OrderIDToolStripLabel As ToolStripLabel
    Friend WithEvents txtOrderIDToolStrip As ToolStripTextBox
    Friend WithEvents FillByToolStripOrder As ToolStripButton
    Friend WithEvents ToolStripFillAllOrders As ToolStripButton
    Friend WithEvents lblOrderTotal As Label
    Friend WithEvents BackToRootsDataSet1 As BackToRootsDataSet
    Friend WithEvents ProductBindingSource As BindingSource
    Friend WithEvents ProductTableAdapter As BackToRootsDataSetTableAdapters.ProductTableAdapter
    Friend WithEvents btnCustomerInfo As Button
    Friend WithEvents OrderPlacementBindingSource As BindingSource
    Friend WithEvents OrderPlacementTableAdapter As BackToRootsDataSetTableAdapters.OrderPlacementTableAdapter
    Friend WithEvents OrderFulfillmentBindingSource As BindingSource
    Friend WithEvents OrderFulfillmentTableAdapter As BackToRootsDataSetTableAdapters.OrderFulfillmentTableAdapter
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents OrderSearchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagementToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrdersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagementToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RewardStatusToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnClose As Button
    Friend WithEvents LineItem As DataGridViewTextBoxColumn
    Friend WithEvents ProductID As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents ProductPrice As DataGridViewTextBoxColumn
    Friend WithEvents LineTotal As DataGridViewTextBoxColumn
End Class
